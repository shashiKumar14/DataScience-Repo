# Create your views here.
from django.shortcuts import render
from django.http import HttpResponse


def home(request):
    return render(request,"home.html",{"name":"shashi"})
def demo(request):
    return render(request,"base.html")

def codecamp(request,*args,**kwargs):
    print(args,kwargs)
    print(request.user)
    return render(request,"codecamp.html")



# def codecamp(request,*args,**kwargs):
#     print(args,kwargs)
#     print(request.user)
#     return HttpResponse("<h1>Hello world</h1>")